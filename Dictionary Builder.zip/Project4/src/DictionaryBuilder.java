import java.io.*;
import java.util.*;

public class DictionaryBuilder {
	
	
	private GenericLinkedList<DictionaryEntry>[] linkTable;
	private int tableS;
	 private int totalW;
	 private int uniqW;
	
	 // constructor 1
	 DictionaryBuilder(int estimatedEntries){
		 
		 
		 int targetS = (int)Math.ceil(estimatedEntries/0.6);
		 this. tableS =  find4kp3prime(targetS);
		 
		 // i did the cast becusr java requires unchecked cast
		 linkTable = (GenericLinkedList<DictionaryEntry>[])new GenericLinkedList[tableS];
		 
		 totalW=0;
		 uniqW = 0;
		 
		 
		 
	 }
	 
	 //constructor 2

	 DictionaryBuilder(String fileName) throws FileNotFoundException {
		 
		 File f = new File(fileName);
		 
		 if(!f.exists()) {
			 
			 throw new FileNotFoundException("File is not found: " + f);
	        }
		 
		long bytes= f.length();
		 
		 int approxTable = (int)Math.max(1, Math.ceil(bytes / 60.0));
		 
		 // here i am adjesting the approximate size to the smallest prime , that is 3 %
		 tableS = find4kp3prime(approxTable);
		 
		 linkTable= (GenericLinkedList<DictionaryEntry>[])new GenericLinkedList[tableS];
		 
		 totalW=0;
		 uniqW = 0;
		 
		  loadFile(fileName);
		 }
		 
	 
	 void addWord(String word) {
		 
		 String w= cleanWord(word);
		 
		 // here i am ignoring blanks after cleaning
		 if(w == null) return;
		 
		 
		 int index= hash(w);
		 
		 //if the likedlist is null the add a new 
		 if(linkTable[index] == null) {
			 
			 linkTable[index] = new GenericLinkedList<>();
			 
		 }
		 
		 // if duplicate found just  then  incment count and totaLW
		 for(var e : linkTable[index] ) {
			 
			 if(e.getWord().equals(w)) {
				 
				 e.increment();
				 totalW++;
				 return;
			 }
		 }
		 
		 // if there no duplictes this addlast to the 
		 // linked list, here is where the chaning happens
		 // also incremet uniqW and totalW
		 
		 linkTable[index].addLast(new DictionaryEntry(w));
		 
		 uniqW++;
		 totalW++;
		 
	 }
	 
	 
	 // this method job is to look up a word and tell
	 // me how menu times that word appread in my dictionary
	 int getFrequency(String word) {
		 
		 String w= cleanWord(word);
		 
		 if(w == null) {
		
			 return 0;
			 
		 }
		 
		 
		 int index = hash(w);
		 
		 var bucket = linkTable[index]; 
		 
		 if(bucket == null) {
			 
			 return 0;
		 }
		 
		 
		 for(var e : bucket) {
			 if(e.getWord().equals(w)) {
				 
				 return e.getCount();
				 
			 }
			 
		 }
		 
		 return 0;
		 
	 }
	 
	 
	 // here i am iterating through the chain linked and if i
	 // find some equal w then remove and also uniqW--,
	 // of bucket == null then well throw exception
	 // return true if no equal then return false
	 boolean removeWord(String word) throws DictionaryEntryNotFoundException {
		 
		 String w= cleanWord(word);
		 if(w == null) {
				
			 return  false;
			 
		 }
		 
		 int index = hash(w);
		 
		 var bucket = linkTable[index]; 
		 
		 if(bucket == null) {
			 throw new DictionaryEntryNotFoundException("not found");
		 }
		 // using Iterator to remove matching node
		 Iterator<DictionaryEntry> itr = bucket.iterator();
		 
		 while(itr.hasNext()) {
			 var e = itr.next();
			 if(e.getWord().equals(w)) {
				 itr.remove();
				 uniqW--;
				 return true;
			 }
			 
		 }
		 return false; 
	 }
	 
	 ArrayList<String> getAllWords(){
		 
		 var allW = new ArrayList<String>();
		 
		 // scaning evey bucket of the array
		 // first scan a bucket then incremnt the array
		 // and scna all the list values.. until tableS-1
		 // then just sort and return
		 
		 for(int i = 0 ; i < tableS ; i++) {
			 
			 var bucket = linkTable[i];	
			
			 // will continue if bucket is null
			 
			 if(bucket == null) {
				 
				 continue;
			 }
			 
			 for(var e : bucket) {
				 
				 allW.add(e.getWord());
				 
			 }
			 
		 }
		 // sorting the arraylist
		 
		 Collections.sort(allW);
		 
		 return allW;
	 }
	 
	 
	 
	 
	 
	 
	 // creating the hash method
	 private int hash(String w) {
		
		 // TODO Auto-generated method stub
		 int index= w.hashCode();
		 
		return Math.abs(index) % tableS;
	}

	 // here i will clean the rawword by making it lowecase and
	 // replacing all spaces using regx
	 private String cleanWord(String rawWord) {
		if(rawWord ==  null) return "";
		
		String word= rawWord.toLowerCase().replaceAll("[^a-z0-9]+", "");
		return word;
	}

	 private int find4kp3prime(int min) {
		// TODO Auto-generated method stub
		 
		 // this will be my safty check , to make sure my
		 // my starting value is at least 3
		 int n = Math.max(3, min);
		 
		 // here i am adding enough to make the 
		 // next num give mod 3
		 if(n % 4 != 3) {
			 
			 n +=(3-(n % 4));
			 
			 }
		 // goes by 4 until i hit prime
		 while(!isPrime(n)) { 
			 
			 n +=4;
		 }
		return n;
	 }
	 
	 // this is my file loading helper class that will read my file,
	 // cleanit  up and  add it to my addword when string becomes empty.
	 private void loadFile(String fileName) {
		 
		 
		 try(Scanner scan = new Scanner(new File(fileName))){
			 
			 
			 
			 while(scan.hasNext()) {
				 
				String raw = scan.next();
				
				String w = cleanWord(raw);
				 
				if(!w.isEmpty()) {
					addWord(w);
				}
				 
				 
			 }
		 }
		 catch(FileNotFoundException e) {
			 
			 throw new IllegalArgumentException("File has not been found: " + fileName);
			 
			 
		 }
		 
	 }

	 private boolean isPrime(int n) {
		// TODO Auto-generated method stub
		 
		 // negative are not prime and small num to
		 if(n<2) {
			 return false;
		 }
		 
		 // the only even prime is 2 so prime 
		 if(n % 2 == 0) {
			 return n == 2;
		 }
		 
		 // checkes if n is not prime by / i and if 
		 // if n % i == 0 then not prime returns false
		 // becuse a prime can't have a divisor other than it
		 // 0, and itself
		 for(int i = 3; i * i <= n; i += 2) {
			 
			 if(n % i == 0) {
				 return false;
			 }
		 }
		return true;
	 }

	 public int getuniqueW() {
		// TODO Auto-generated method stub
		return uniqW;
	 }

	 public int gettotalW() {
		// TODO Auto-generated method stub
		return totalW;
	 }
	
	 

}
