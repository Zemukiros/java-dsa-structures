import java.util.*;

public class GenericLinkedList<T> implements Iterable<T> {
	
	
	// here i will be creating my inner node 
	// that stores has a pervious and a next and a T value
	
	
	private static class Node<T>{
		
		T value; // this is the  actual value
		Node<T> previous; 
		Node<T> next;
		
		// constructor for my node
		
		Node(T value){
			
			this.value=value;
			
		}
		
		
		
		
	}
	
	
	
	    // my lists fields
	
	
			private Node<T> first;
			
			private Node<T> last;
			
			private int count;
	
	// my Lists constructor
	
      public GenericLinkedList() {
    	       first = last = null; 
		        count=0;    
		    }
      
      
      
      
      // this return the num of element in my list
      
      public int size() {
    	   
    	  return count;
    	  
    	  
      }
      
    
      // return true if list is empty
      
      public boolean isEmpty() {
    	  
    	  return count == 0; 
    	  
      }
      
      //if indx < 0 or > count then  indexOutOfBoundException
      void checkIndex(int index) {
    	  
    	  if(index < 0 || index >= count) {
    		  
    		  throw new IndexOutOfBoundsException("Index can't be < 0 or > count");
    	  }
    	  
    	  
      }
      
      // i did this to clear the list and make the list empty 
      void clear() {
          first = last = null;
          count = 0;
      }
      
      // here i am adding a contain method to check to perevent any
      // duplication and and see if any math the value i am 
      //looking for
      
      // i did this to not write again and again later
      // make sure list is not empty
      void checkIsEmpty() {
    	  
    	  if (isEmpty()) {
    	        throw new NoSuchElementException("the list cannot be empty!!");
    	    }
    	  
      }
      
      boolean contains(T e) {
    	  
    	  // starting from first and loping through to check
    	  // if curr.value.equal(e) and return T if equals or F if not 
    	  Node curr = first;
    	   
    	  while(curr != null) {
    		  
    		  if(curr.value.equals(e)) { 
    			  return true;
    		  }
    			  curr = curr.next;
    			 
    	  }
    	 
    	  return false; 
      }
      
      
      // okay now lets get current node
      
      Node getNode( int index) {
    	  
    	  
    	  checkIndex(index);
    	  
    	  
    	  // this will be the node i will return
    	  Node curr;
    	  
    	  // here if index is in the first half
    	  // i will start from the first and go curr.next until we find node 
    	  // else i will start from last and go curr.prev backword until we find node
    	  
 
    	  if(count/2 > index) {
    		  
    		  curr=first;
    		  
    		  for(int i=0 ; i<index ; i++) {
    			  
    			  curr = curr.next;
    			 
    		  }
    		  
    		  
    	  }
    	  else {
    		  
    		  curr = last;
    		  
    		  for(int i = count-1 ; i > index ; i-- ) {
    			  
    			  curr = curr.previous;
    		  }
    		  
    		 
    	  }
    	  
    	  return curr;
    	   
      }
      
      
      // this will add to the begining of the list
      
      void addFirst(T v) {
    	  
    	  // creating new node to hold v
    	  Node<T>node =  new Node<>(v);
    	  
    	  
    	  // if isEmpty then make  first= last = node
    	  // else node.next=first , first.prevous = node,  first = node
    	  //   then count++
    	  if(isEmpty()) {
    		  
    		  first = last = node;
    		  
    	  }
    	  
    	  else {
    		  
    		  node.next = first;
    		  first.previous = node;
    		  first = node;
 		  
     	  }
    	  
    	  count ++;
    
      }
      

      // this will add to the end 
      
      void addLast(T v) {
    	  
    	  Node<T> node = new Node<>(v);
    	  
    	  // same shit as addfirst 
    	  //but in else last.next = node, nod.prevous= last ,last = node
    	  if(isEmpty()) {
    		  
    		  first = last = node;
    	  }
    	  
    	  else {
    		
    		  
    		  last.next=node;
    		  node.previous=last;
    		  last=node;
    		  
    	  }
    	  
    	  count++;
    	  
    	  
      }
      
      
      // here i am getting the data  getNode.value
      
       T get(int index){
    	  
    	  return (T) getNode(index).value;
      }
      
      // return first value without removing
     T getFirst() {
    	  
    	 checkIsEmpty();
    	 
    	  return first.value;
      }
      
     // return last value without removing
      T getLast() {
    	  
    	  checkIsEmpty();
    	  
    	  return last.value;
      }
      
      
      // here i am returing first and also removing it
      T removeFirst() {
    	 
    	  checkIsEmpty();
    	  
    	 T v=  first.value;
    	  
    	 // here if  count not 1 then i move first to first.next
    	 // and first.prev = null, then return v
    	 if(count!= 1) {
    		 
    		 first = first.next;
    		 first.previous=null;
    	 }
    	 
    	 else {
    		 
    		 first = last = null;
    	 }
    	 count--;
    	 
    	  return v;
      }
      
      
      //
      
      // here same thing as above but for the last
      T removeLast() {
    	  
    	  checkIsEmpty();
    	  
    	  
    	  T v = last.value;
    	  
    	  if(count != 1) {
    		  
    		 last = last.previous;
    		 last.next=null; 
    	  }
    	  else {
    		  
    		  first=last=null;
    	  }
    	  
    	  count--;
    	  
    	  return v;
    	  
    	  
    	  
      }
      
     
      
      //  here i am removing at a at specfic index and returng it
      // will do by savint the targets previous and next and 
      // then skiping target and conceting the target neighbors to 
      // eachother
      
      T remove(int index) {
    	  
    	  checkIndex(index);
    	  
    	  //return first or last
    	  if(index == 0) {return removeFirst();}
    	  if(index == count-1) {return removeLast();}
    	  
    	   Node<T> tar = getNode(index);
    	   T v = tar.value;
    	   
    	  
    	   // here saving targ prev and next
    	   
    	   Node<T> nodPrevious = tar.previous;
    	   Node<T> nodeNext = tar.next;
    	   
    	   // conecting the two
    	   
    	   nodPrevious.next = nodeNext;
    	   nodeNext.previous =nodPrevious;
    	
    	   
    	   count -- ;
    	   
    	   return v;
      }
      
      
      //this Removes the first occurrence of the 
      //specified element from the list. 
      // so basically here i am  removeing by value unlike the above that remove
      //by position
      
     Boolean remove(T element) {
    	 
    	 Node curr = first;
  	   
   	  while(curr != null) {
   		  
   		  if(curr.value.equals(element)) { 
   			  
   			  if(curr == first) { 
   				  removeFirst();
   				
   			  }
   			  else if(curr == last) {
   				  removeLast();
   			  }
   			  else {
   		Node<T> nodPrevious = curr.previous;
 	   Node<T> nodeNext = curr.next;
 	   nodPrevious.next = nodeNext;
 	   nodeNext.previous =nodPrevious;
   		
 	   count--;  
   		  }
   			return true;  
   		  }
   		  
   		  curr = curr.next;
   	  }
   	 
   	  return false; 
     }
    	 
    	 
     
     
     
     
      
   
      // here i am converting to an array containing all 
      // value in order 
      public T[] toArray() {
  		
		   T[] newArray = (T[])new Object[count];
		   
		   Node curr = first;
		   int index = 0;
	    
		   while(curr != null) {
			   
			   newArray[index++] = (T) curr.value;
			   curr= curr.next;
		   }
		   return newArray;
	} 
      
      
      // 
      
      
     
      
      
      private  class GenericIterator implements ListIterator<T> {
    	  
    	  private Node next;
    	  private  Node lastReturn;
    	  private int nextIndex;
    	  
    	  
    	  public GenericIterator() {
    		  
    		  next=first;
    		  lastReturn=null;
    		  nextIndex=0;
    		  
    	  }
    	  
    	  
    	  // this is  simple it check to see if next not null
		  @Override
		  public boolean hasNext() {
			
			return next != null;
		  }
		  
		  @Override
		  public T next() {
		
			  // if hasNext false throw NoSuchElementException
			  if(!hasNext()) {
				  
				  throw new NoSuchElementException();
			  }
			  
			  // here i am returning next, so i need to make it = lastreturned
			  // and move next onestep, all increment nextindex, then return lastReturned value
			  
			
			  
			  lastReturn = next;
			  next=next.next;
			  nextIndex++;
			  
			 return (T) lastReturn.value;
		  }
		  
		  // do same with pervious but backward so nexIndex > 0
		  @Override
		  public boolean hasPrevious() {
			
			return nextIndex > 0;
		  }
		  
		  @Override
		  public T previous() {

			  if(!hasPrevious()) {
				  
				  throw new NoSuchElementException();
			  }
			
			 // if next is null it means i am at the past the end 
			 //so my previous would be last itself
			  // if next != null then i am somewere in the
			  // list i just need to move backword 
			 
			  if(next == null) {
				  
				  next = last;
			  }
			  else {
				  
				  next=next.previous;
				  lastReturn = next;
				  nextIndex--;
			  }
			  
			  
			return (T) lastReturn.value;
		  }
		  
		  
		  // here i am removing the last node i returned by next or previous
		  @Override
		  public void remove() {
			
			  if (lastReturn == null) throw new IllegalStateException("there's is nothing to remove here!");

			    Node<T> lReturnP = lastReturn.previous;
			    Node<T> lReturnN= lastReturn.next;

			    
			    // here i will remove the first node if IRetP== null
			    // else i remove last if IRetN= null
			    // else i will remove from the middle
			    
			    if (lReturnP == null) {
			    	
			        GenericLinkedList.this.removeFirst();
			       
			    } else if (lReturnN == null) {
			        
			        GenericLinkedList.this.removeLast();
			        
			    } else {
			        
			        lReturnP.next = lReturnN;
			        lReturnN.previous = lReturnP;
			        count--;
			    }

			    
			    if (next == lastReturn) {
			        
			        next = lReturnN;
			    } else {
			        
			        nextIndex--;
			    }

			    lastReturn = null;
			  
		  }
		  
		  
		  
		  @Override
		  public int nextIndex() {
			
			  return nextIndex;
		  }
		  @Override
		  public int previousIndex() {
			
			  return nextIndex - 1 ;
		  }


		  @Override
		  public void set(T e) {
			  throw new UnsupportedOperationException();
			
		  }


		  @Override
		  public void add(T e) {
			  throw new UnsupportedOperationException();
			
		  }
			
			
		  }
		 

	  @Override
	  public ListIterator<T> iterator() {
		    return new GenericIterator();
		}
      
      
      
      
      
	
	

}
