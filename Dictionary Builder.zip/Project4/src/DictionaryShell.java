import java.util.*;
import java.io.*;
public class DictionaryShell {
	
	public static void main(String[] args) throws FileNotFoundException, DictionaryEntryNotFoundException {
		
		Scanner scan = new Scanner(System.in);
		
		DictionaryBuilder d;
		
		// here if there a filename  load
		// else no filename, so start from empty,
		
		if(args.length == 1) {	
			d = new DictionaryBuilder(args[0]);
		}
		else {	
			
			d= new DictionaryBuilder(args[100]);
		}
		
		
		
		// here i  creat a switch to  read the line
		//splite into two parts the comand and the rest 
		// i will make lowercass, then add  if there argument
		// get count,, will remove word from the dictionary,
		// if case list will print evry uniq word sorted,
		// will add stats that prints the uniq word an total word.
		while(scan.hasNext()) {
			
			
			
			var lin= scan.nextLine().trim();
			
			if(lin.isEmpty())continue;
			
			String[] part = lin.split("\\s+",2);
			
			String c= part[0].toLowerCase();
			
			String arg;
			if(part.length>1) {
				
				arg=part[1].trim();
			}else {
				arg="";
			}
			
			
			switch(c) {
				
			case "add": {
				
				
				if(!arg.isEmpty()) {
					
					d.addWord(arg);
					
				}
				break;
		}
		
			case "search" : {
				
				 if (!arg.isEmpty()) {
			            int freq = d.getFrequency(arg);
			            System.out.println(arg.toLowerCase() + " " + freq);
			        }
			        break;
			}
			
			case "delete": {
				
				if (arg.isEmpty()) {
					break;
				}
				else {
					
					d.removeWord(arg);
				}
				break;
			}
			
			case "list": {
			   
			    for (var w : d.getAllWords()) {
			        System.out.println(w);
			    }
			    break;
			}
			
			case "stats": {
				
				  System.out.println("unique words is  " + d.getuniqueW());
				    System.out.println("total words si  " + d.gettotalW());
			}
			   break;
			case "exit": {
			    
			    return;
			}
		
			default: {
		        
		        break;
		    }
			
		}
		}
		
	}

	
	
	
	
	
	
}
