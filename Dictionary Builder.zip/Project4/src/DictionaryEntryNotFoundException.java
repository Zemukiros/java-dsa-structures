
public class DictionaryEntryNotFoundException  extends Exception {
	
	public DictionaryEntryNotFoundException(String mess) {
        super(mess);
    }
	
	

}
