import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import org.junit.Before;
import org.junit.Test;


public class DictionaryBuilderStudentTests {

	
	private DictionaryBuilder d;

    @Before 
    public void setup() {
        d = new DictionaryBuilder(16);
    }

    @Test
    public void adds() {
        d.addWord("Apple");
        d.addWord("apple!");
        d.addWord("APPLE,");
        d.addWord("  aPpLe  ");

        assertEquals(1, d.getuniqueW());
        assertEquals(4, d.getFrequency("apple"));
        assertEquals(4, d.gettotalW()); 
    }

    @Test
    public void searchs() {
        d.addWord("the");
        d.addWord("the");
        d.addWord("cat");

        assertEquals(2, d.getFrequency("the"));
        assertEquals(1, d.getFrequency("cat"));
        assertEquals(0, d.getFrequency("dog"));
    }

    @Test
    public void remove() throws DictionaryEntryNotFoundException {
        d.addWord("red");
        d.addWord("red");
        d.addWord("blue");

        assertEquals(2, d.getuniqueW());

        d.removeWord("red");

        assertEquals(1, d.getuniqueW());
        assertEquals(0, d.getFrequency("red"));
        assertEquals(1, d.getFrequency("blue"));
    }

    @Test
    public void edgeCases() {
        assertEquals(0, d.getFrequency("nothing"));
        assertThrows(DictionaryEntryNotFoundException.class, () -> d.removeWord("ghost"));
    }
	
	
	
}
