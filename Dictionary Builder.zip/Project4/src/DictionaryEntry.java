



public class DictionaryEntry {

	private String word;
	private int count;
	
	
	DictionaryEntry(String w){
		this.word=w;
		count=1;
		
	}
	
	public String getWord() {
		
		return word;
	}
	
	public int getCount() {
		
		return count;
	}
	
	
	public void increment() {
		
		count++;
	}
	
}
