import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class GraphTestStudent {
	

	private Graph graph;
	private Town addis, mekelle, gondar, bahirdar, hawassa;
	

	@Before
	public void setUp() throws Exception {
		
		// set up towns
		graph = new Graph();
		addis = new Town("Addis Ababa");
		mekelle = new Town("Mekelle");
		gondar = new Town("Gondar");
		bahirdar = new Town("Bahir Dar");
		hawassa = new Town("Hawassa");

		// add different towns to the graph
		graph.addVertex(addis);
		graph.addVertex(mekelle);
		graph.addVertex(gondar);
		graph.addVertex(bahirdar);
		graph.addVertex(hawassa);

		// also add roads
		graph.addEdge(addis, mekelle, 10, "Highway 1");
		graph.addEdge(addis, gondar, 20, "Highway 2");
		graph.addEdge(mekelle, bahirdar, 15, "Highway 3");
		graph.addEdge(gondar, bahirdar, 5, "Highway 4");
		graph.addEdge(bahirdar, hawassa, 8, "Highway 5");
	}

	@After
	public void tearDown() throws Exception {
		
		graph = null;
		addis = mekelle = gondar = bahirdar = hawassa = null;
		
	}

	@Test
	public void testGetEdge() {
		
		Road road = graph.getEdge(addis, mekelle);
		assertNotNull(road);
		assertEquals("Highway 1", road.getName());
		
	}

	@Test
	public void testAddEdge() {
		
		Road road = graph.addEdge(addis, hawassa, 12, "Expressway 1");
		assertNotNull(road);
		assertTrue(graph.containsEdge(addis, hawassa));
		assertEquals("Expressway 1", road.getName());
		
	}

	@Test
	public void testAddVertex() {
		
		Town direDawa = new Town("Dire Dawa");
		assertTrue(graph.addVertex(direDawa));
		assertTrue(graph.containsVertex(direDawa));
		
	}

	@Test
	public void testContainsEdge() {
		
		assertTrue(graph.containsEdge(gondar, bahirdar));
		assertFalse(graph.containsEdge(mekelle, hawassa));
		
	}

	@Test
	public void testContainsVertex() {
		
		assertTrue(graph.containsVertex(addis));
		assertFalse(graph.containsVertex(new Town("Axum")));
		
	}

	@Test
	public void testEdgeSet() {
		
		Set<Road> allRoads = graph.edgeSet();
		assertEquals(5, allRoads.size());
		
	}

	@Test
	public void testEdgesOf() {
		
		Set<Road> roadsFromAddis = graph.edgesOf(addis);
		assertEquals(2, roadsFromAddis.size());
		
	}

	@Test
	public void testRemoveEdge() {
		
		assertTrue(graph.containsEdge(mekelle, bahirdar));
		graph.removeEdge(mekelle, bahirdar, 15, "Highway 3");
		assertFalse(graph.containsEdge(mekelle, bahirdar));
		
	}

	@Test
	public void testRemoveVertex() {
		
		assertTrue(graph.containsVertex(gondar));
		graph.removeVertex(gondar);
		assertFalse(graph.containsVertex(gondar));
		
	}

	@Test
	public void testVertexSet() {
		
		Set<Town> allTowns = graph.vertexSet();
		assertEquals(5, allTowns.size());
	}

	@Test
	public void testDijkstraShortestPath() {
		
		// no exception should be thrown because Mekelle should be distance 10, Bahir Dar should be 25 through Mekelle
		graph.dijkstraShortestPath(addis);
		
	}

	@Test
	public void testShortestPath() {
		
		ArrayList<String> path = graph.shortestPath(addis, hawassa);

		assertNotNull(path);
		assertEquals(3, path.size());
		assertEquals("Addis Ababa via Highway 1 to Mekelle 10 mi", path.get(0));
		assertEquals("Mekelle via Highway 3 to Bahir Dar 15 mi", path.get(1));
		assertEquals("Bahir Dar via Highway 5 to Hawassa 8 mi", path.get(2));
		
	}
}
