
import java.util.Objects;

public class Town implements Comparable<Town> {
	
    private String name;

    // this constructor creates a town with a given name
    public Town(String name) {
    	
        this.name = name;
    }

    // creates a new town by copying another Towns object
    public Town(Town templateTown) {
    	
        this.name = templateTown.name;
    }

    // rturns the name of  a town
    public String getName() {
    	
        return name;
    }

    // compares this town to another by thier alphabets
    @Override
    public int compareTo(Town other) {
    	
        return this.name.compareToIgnoreCase(other.name);
        
    }

    // checks if this town is equal to another town( if thier name is similar then they are equal)
    @Override
    public boolean equals(Object obj) {
    	
        if (obj instanceof Town) {
        	
            return this.name.equalsIgnoreCase(((Town) obj).name);
        }
        
        return false;
    }

    // returns the hash code of the town based on its name
    @Override
    public int hashCode() {
    	
        return Objects.hash(name.toLowerCase());
        
    }

    
    @Override
    public String toString() {
        return name;
    }
}

