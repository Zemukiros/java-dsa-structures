import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TownTestStudent {

    private Town town1;
    private Town town2;
    private Town town3;

    @Before
    public void setUp() throws Exception {
    	
        town1 = new Town("Addis Ababa");
        town2 = new Town("Mekelle");
        town3 = new Town("addis ababa"); 
        
    }

    @After
    public void tearDown() throws Exception {
    	
        town1 = null;
        town2 = null;
        town3 = null;
    }

    @Test
    public void testHashCode() {
    	
        assertEquals(town1.hashCode(), town3.hashCode());  
        assertNotEquals(town1.hashCode(), town2.hashCode()); 
        
    }

    @Test
    public void testTownString() {
    	
        Town t1 = new Town("Gondar");
        assertEquals("Gondar", t1.getName());
        
    }

    @Test
    public void testTownTown() {
    	
        Town copy = new Town(town2);
        assertEquals("Mekelle", copy.getName());
        assertNotSame(town2, copy); 
        
    }

    @Test
    public void testGetName() {
    	
        assertEquals("Addis Ababa", town1.getName());
        assertEquals("Mekelle", town2.getName());
        
    }

    @Test
    public void testCompareTo() {
    	
        assertTrue(town1.compareTo(town2) < 0);   
        assertTrue(town2.compareTo(town1) > 0);   
        assertEquals(0, town1.compareTo(town3));  
        
    }

    @Test
    public void testEqualsObject() {
    	
        assertTrue(town1.equals(town3));            
        assertFalse(town1.equals(town2));           
        assertFalse(town1.equals("NotATown"));      
        assertFalse(town1.equals(null));    
        
    }

    @Test
    public void testToString() {
    	
        assertEquals("Addis Ababa", town1.toString());
        assertEquals("Mekelle", town2.toString());
        
    }
}
