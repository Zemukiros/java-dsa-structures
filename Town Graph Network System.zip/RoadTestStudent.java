import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RoadTestStudent {

    private Town addisAbaba;
    private Town mekelle;
    private Town bahirDar;
    
    private Road road1;
    private Road road2;
    private Road road3;
    private Road road4;

    @Before
    public void setUp() throws Exception {
    	
        addisAbaba = new Town("Addis Ababa");
        mekelle = new Town("Mekelle");
        bahirDar = new Town("Bahir Dar");

        road1 = new Road(addisAbaba, mekelle, 800, "Ethio Highway 1");
        road2 = new Road(mekelle, addisAbaba, 800, "Ethio Highway 1"); 
        road3 = new Road(addisAbaba, bahirDar, 550, "Blue Nile Road");
        road4 = new Road(addisAbaba, mekelle, 800, "Ethio Highway 2"); // same towns, different name
    }

    @After
    public void tearDown() throws Exception {
    	
        addisAbaba = null;
        mekelle = null;
        bahirDar = null;
        road1 = null;
        road2 = null;
        road3 = null;
        road4 = null;
        
    }

    
    @Test
    public void testContains() {
    	
        assertTrue(road1.contains(addisAbaba));
        assertTrue(road1.contains(mekelle));
        assertFalse(road1.contains(bahirDar));
        
    }

    @Test
    public void testGetDestination() {
    	
        assertEquals(mekelle, road1.getDestination());
        assertEquals(bahirDar, road3.getDestination());
        
    }

    @Test
    public void testGetSource() {
    	
        assertEquals(addisAbaba, road1.getSource());
        assertEquals(addisAbaba, road3.getSource());
        
    }

    @Test
    public void testGetWeight() {
    	
        assertEquals(800, road1.getWeight());
        assertEquals(550, road3.getWeight());
        
    }

    @Test
    public void testGetName() {
    	
        assertEquals("Ethio Highway 1", road1.getName());
        assertEquals("Blue Nile Road", road3.getName());
        
    }

    @Test
    public void testGetOtherTown() {
    	
        assertEquals(mekelle, road1.getOtherTown(addisAbaba));
        assertEquals(addisAbaba, road1.getOtherTown(mekelle));
        assertNull(road1.getOtherTown(bahirDar)); // not a  part of the road
    }

    @Test
    public void testCompareTo() {
    	
        assertTrue(road1.compareTo(road3) > 0);  
        assertTrue(road3.compareTo(road1) < 0);  
        assertEquals(0, road1.compareTo(road2)); 
        
    }

    @Test
    public void testEquals() {
    	
        assertTrue(road1.equals(road2));      
        assertFalse(road1.equals(road3));    
        assertFalse(road1.equals(road4));     
        
    }

    @Test
    public void testToString() {
    	
        String expected = "Ethio Highway 1, 800 miles; Addis Ababa; Mekelle";
        
        assertEquals(expected, road1.toString());
    }
}

