
public class Road implements Comparable<Road> {
	
	// declare the neccassary variables
    private Town town1;
    private Town town2;
    private int weight;
    private String name;

    // this constructor creates a road between two towns with a given name and weight
    public Road(Town town1, Town town2, int weight, String name) {
    	
        this.town1 = town1;
        this.town2 = town2;
        this.weight = weight;
        this.name = name;
        
    }

    // checks whether one town is connected by a road to another
    public boolean contains(Town town) {
    	
        return town.equals(town1) || town.equals(town2);
        
    }

    // gets the ending point of the road
    public Town getDestination() {
    	
        return town2;
        
    }

    // gets the starting point of the road
    public Town getSource() {
    	
        return town1;
    }

    // gets the weight or distance of the road
    public int getWeight() {
    	
        return weight;
    }

    // gets the name of the road
    public String getName() {
    	
        return name;
    }

    public Town getOtherTown(Town current) {
    	
        if (current.equals(town1)) 
        	return town2;
        
        if (current.equals(town2)) 
        	return town1;
        
        return null;
        
    }

    // compares this road to another road based on the road name
    @Override
    public int compareTo(Road other) {
    	
        return this.weight - other.weight;
        
    }

    // checks whether two roads are similar
    @Override
    public boolean equals(Object obj) {
    	
        if (obj instanceof Road) {
        	
            Road other = (Road) obj;
            
            return this.name.equalsIgnoreCase(other.name)
                && ((town1.equals(other.town1) && town2.equals(other.town2)) ||
                    (town1.equals(other.town2) && town2.equals(other.town1)));
        }
        
        return false;
        
    }
    
    // generates a hash code for the road
    @Override
    public int hashCode() {
    	
        // makes the hash direction independent and based on towns and road name
        return town1.hashCode() + town2.hashCode() + name.toLowerCase().hashCode();
        
    }

    // returns the name of the road, its distance and the towns it connects as string representation
    @Override
    public String toString() {
    	
        return name + ", " + weight + " miles; " + town1 + "; " + town2;
        
    }
}
