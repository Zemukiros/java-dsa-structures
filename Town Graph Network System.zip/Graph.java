
import java.io.File;
import java.util.*;

 
public class Graph implements GraphInterface<Town, Road> {

	// declare needed variables
    private Set<Town> towns;
    private Set<Road> roads;
    
    private Map<Town, Integer> distances;
    private Map<Town, Town> previous;

    // this constructor
    public Graph() {
        towns = new HashSet<>();
        roads = new HashSet<>();
    }

    
    @Override
    public Road getEdge(Town sourceVertex, Town destinationVertex) {
    	
        if (sourceVertex == null || destinationVertex == null) 
        	return null;
        
        for (Road road : roads) {
            if (road.contains(sourceVertex) && road.contains(destinationVertex)) {
                return road;
            }
        }
        
        return null;
    }

    // adds a road (edge) between two towns(vertices)
    @Override
    public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
    	
        if (sourceVertex == null || destinationVertex == null)
            throw new NullPointerException("Vertices cannot be null.");
        
        if (!towns.contains(sourceVertex) || !towns.contains(destinationVertex))
            throw new IllegalArgumentException("Vertices must exist in the graph.");

        Road road = new Road(sourceVertex, destinationVertex, weight, description);
        roads.add(road);
        
        return road;
    }

    //adds a town to the graph
    @Override
    public boolean addVertex(Town v) {
    	
        if (v == null) 
        	throw new NullPointerException("Vertex cannot be null.");
        
        return towns.add(v);
    }

    // returns true if the graph contains the given road
    @Override
    public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
    	
        return getEdge(sourceVertex, destinationVertex) != null;
        
    }

    // returns true if the graph contains the town
    @Override
    public boolean containsVertex(Town v) {
    	
        return towns.contains(v);
    }

    // returns a set of all roads in the graph
    @Override
    public Set<Road> edgeSet() {
    	
        return roads;
    }

    // returns a set of all the  roads connected to  town
    @Override
    public Set<Road> edgesOf(Town vertex) {
    	
        if (!towns.contains(vertex)) 
        	throw new IllegalArgumentException("Town not found in graph.");
        
        Set<Road> result = new HashSet<>();
        
        for (Road road : roads) {
        	
            if (road.contains(vertex)) result.add(road);
        }
        
        return result;
        
    }

    // removes a road from the graph
    @Override
    public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
    	
        Road target = new Road(sourceVertex, destinationVertex, weight, description);
        
        if (roads.remove(target)) 
        	return target;
        
        return null;
    }

    // removes the  town from the graph and any connected roads
    @Override
    public boolean removeVertex(Town v) {
    	
        if (v == null || !towns.contains(v)) 
        	return false;

        // remove all roads connected to this town
        roads.removeIf(road -> road.contains(v));
        return towns.remove(v);
        
    }

    @Override
    public Set<Town> vertexSet() {
        return towns;
    }

    // implements Dijkstra's algorithm to compute shortest path from a starting town
    @Override
    public void dijkstraShortestPath(Town sourceVertex) {
    	
        distances = new HashMap<>();
        previous = new HashMap<>();
        
        Set<Town> visited = new HashSet<>();
        PriorityQueue<Town> pq = new PriorityQueue<>(Comparator.comparingInt(distances::get));

        for (Town town : towns) {
        	
            distances.put(town, Integer.MAX_VALUE);
            previous.put(town, null);
            
        }

        distances.put(sourceVertex, 0);
        pq.add(sourceVertex);

        while (!pq.isEmpty()) {
        	
            Town current = pq.poll();
            visited.add(current);

            for (Road road : edgesOf(current)) {
            	
                Town neighbor = road.getOtherTown(current);
                
                if (visited.contains(neighbor)) 
                	continue;

                int newDist = distances.get(current) + road.getWeight();
                if (newDist < distances.get(neighbor)) {
                	
                    distances.put(neighbor, newDist);
                    previous.put(neighbor, current);
                    pq.add(neighbor);
                    
                }
            }
        }
    }

    // Returns the list of road names along the shortest path
    @Override
    public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
    	
        ArrayList<String> path = new ArrayList<>();
        dijkstraShortestPath(sourceVertex);

        Town current = destinationVertex;
        if (previous.get(current) == null && !sourceVertex.equals(destinationVertex)) 
        	return path;

        while (previous.get(current) != null) {
        	
            Town prev = previous.get(current);
            Road road = getEdge(prev, current);
            path.add(0, prev + " via " + road.getName() + " to " + current + " " + road.getWeight() + " mi");
            current = prev;
            
        }

        return path;
    }
}

