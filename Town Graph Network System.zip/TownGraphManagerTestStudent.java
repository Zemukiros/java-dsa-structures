import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TownGraphManagerTestStudent {

    private TownGraphManager manager;
    

    @Before
    public void setUp() throws Exception {
    	
        manager = new TownGraphManager();
        manager.addTown("Addis Ababa");
        manager.addTown("Mekelle");
        manager.addTown("Bahir Dar");
        manager.addRoad("Addis Ababa", "Mekelle", 600, "Unity Road");
        manager.addRoad("Addis Ababa", "Bahir Dar", 550, "Friendship Highway");
    }

    @After
    public void tearDown() throws Exception {
    	
        manager = null;
        
    }

    @Test
    public void testAddRoad() {
    	
        assertTrue(manager.addRoad("Mekelle", "Bahir Dar", 300, "Northern Link"));
        assertTrue(manager.containsRoadConnection("Mekelle", "Bahir Dar"));
        assertEquals("Northern Link", manager.getRoad("Mekelle", "Bahir Dar"));
        
    }

    @Test
    public void testGetRoad() {
    	
        assertEquals("Unity Road", manager.getRoad("Addis Ababa", "Mekelle"));
        assertNull(manager.getRoad("Mekelle", "Hawassa"));
        
    }

    @Test
    public void testAddTown() {
    	
        assertTrue(manager.addTown("Hawassa"));
        assertTrue(manager.containsTown("Hawassa"));
        
    }

    @Test
    public void testContainsTown() {
    	
        assertTrue(manager.containsTown("Addis Ababa"));
        assertFalse(manager.containsTown("Dire Dawa"));
        
    }

    @Test
    public void testContainsRoadConnection() {
    	
        assertTrue(manager.containsRoadConnection("Addis Ababa", "Mekelle"));
        assertFalse(manager.containsRoadConnection("Mekelle", "Dire Dawa"));
        
    }

    @Test
    public void testAllRoads() {
    	
        ArrayList<String> roads = manager.allRoads();
        assertEquals(2, roads.size());
        assertTrue(roads.contains("Unity Road"));
        assertTrue(roads.contains("Friendship Highway"));
        
    }

    @Test
    public void testDeleteRoadConnection() {
    	
        assertTrue(manager.deleteRoadConnection("Addis Ababa", "Mekelle", "Unity Road"));
        assertFalse(manager.containsRoadConnection("Addis Ababa", "Mekelle"));
        
    }

    @Test
    public void testDeleteTown() {
    	
        assertTrue(manager.deleteTown("Mekelle"));
        assertFalse(manager.containsTown("Mekelle"));
        
    }

    @Test
    public void testAllTowns() {
    	
        ArrayList<String> towns = manager.allTowns();
        assertEquals(3, towns.size());
        assertTrue(towns.contains("Addis Ababa"));
        assertTrue(towns.contains("Mekelle"));
        assertTrue(towns.contains("Bahir Dar"));
        
    }

    @Test
    public void testGetPath() {
    	
        manager.addRoad("Mekelle", "Bahir Dar", 300, "Northern Link");
        ArrayList<String> path = manager.getPath("Addis Ababa", "Bahir Dar");
        assertNotNull(path);
        assertTrue(path.get(0).contains("via Friendship Highway"));
        
    }
}
