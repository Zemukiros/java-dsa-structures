
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;


public class TownGraphManager implements TownGraphManagerInterface {

    private Graph graph;

    // this constructor initializes the graph object
    public TownGraphManager() {
    	
        graph = new Graph();
    }

    // adds a road (edge) between two towns in the graph
    @Override
    public boolean addRoad(String town1, String town2, int weight, String roadName) {
    	
        Town t1 = new Town(town1);
        Town t2 = new Town(town2);

        if (!graph.containsVertex(t1)) 
        	graph.addVertex(t1);
        if (!graph.containsVertex(t2)) 
        	graph.addVertex(t2);

        graph.addEdge(t1, t2, weight, roadName);
        
        return true;
    }

    //  returns the name of the road connecting two town
    @Override
    public String getRoad(String town1, String town2) {
    	
        Town t1 = new Town(town1);
        Town t2 = new Town(town2);

        Road road = graph.getEdge(t1, t2);
        return (road != null) ? road.getName() : null;
    }

    @Override
    public boolean addTown(String v) {
    	
        return graph.addVertex(new Town(v));
    }

    @Override
    public Town getTown(String name) {
    	
        for (Town town : graph.vertexSet()) {
        	
            if (town.getName().equalsIgnoreCase(name)) {
                return town;
            }
        }
        
        return null;
    }

    // checks if a town is in the graph
    @Override
    public boolean containsTown(String v) {
    	
        return graph.containsVertex(new Town(v));
        
    }

    // checks if a road connection exists between two towns
    @Override
    public boolean containsRoadConnection(String town1, String town2) {
    	
        return graph.containsEdge(new Town(town1), new Town(town2));
        
    }

    // returns a sorted list of all road names in the graph
    @Override
    public ArrayList<String> allRoads() {
    	
        ArrayList<String> roads = new ArrayList<>();
        
        for (Road road : graph.edgeSet()) {
            roads.add(road.getName());
        }
        
        Collections.sort(roads);
        return roads;
    }

    // deletes a road connection between two towns
    @Override
    public boolean deleteRoadConnection(String town1, String town2, String road) {
    	
        Road target = graph.getEdge(new Town(town1), new Town(town2));
        
        if (target != null && target.getName().equalsIgnoreCase(road)) {
        	
            graph.removeEdge(new Town(town1), new Town(town2), target.getWeight(), target.getName());
            return true;
        }
        
        return false;
    }

    @Override
    public boolean deleteTown(String v) {
    	
        return graph.removeVertex(new Town(v));
    }
    
    public void populateTownGraph(File file) throws FileNotFoundException {
    	
        Scanner scanner = new Scanner(file);
        
        while (scanner.hasNextLine()) {
        	
            String line = scanner.nextLine();
            
            String[] parts = line.split(";");
            
            if (parts.length == 4) {
            	
                String roadName = parts[0].trim();
                int weight = Integer.parseInt(parts[1].trim());
                String town1 = parts[2].trim();
                String town2 = parts[3].trim();
                
                addRoad(town1, town2, weight, roadName);
            }
        }
        
        scanner.close();
    }

    // returns a sorted list of all towns in the graph
    @Override
    public ArrayList<String> allTowns() {
    	
        ArrayList<String> towns = new ArrayList<>();
        
        for (Town town : graph.vertexSet()) {
            towns.add(town.getName());
        }
        
        Collections.sort(towns);
        return towns;
    }

    // returns the shortest path between two towns
    @Override
    public ArrayList<String> getPath(String town1, String town2) {
    	
        return graph.shortestPath(new Town(town1), new Town(town2));
    }
}

