import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MorseCodeTreeTestStudent {

	MorseCodeTree tree;

	@Before
	public void setUp() throws Exception {
		
		tree = new MorseCodeTree(); 
	}

	@After
	public void tearDown() throws Exception {
		
		tree = null;
	}

	@Test
	public void testMorseCodeTree() {
		
		assertNotNull("Tree should be initialized in constructor", tree);
		assertNotNull("Root should not be null", tree.getRoot());
		assertEquals("Root should have empty string", "", tree.getRoot().data);
	}

	@Test
	public void testBuildTree() {
		
		assertEquals("Letter for '.-' should be 'a'", "a", tree.fetch(".-"));
		assertEquals("Letter for '--.' should be 'g'", "g", tree.fetch("--."));
		assertEquals("Letter for '.--.' should be 'p'", "p", tree.fetch(".--."));
	}

	@Test
	public void testGetRoot() {
		
		assertEquals("Root node should hold an empty string", "", tree.getRoot().data);
	}

	@Test
	public void testSetRoot() {
		
		TreeNode<String> newRoot = new TreeNode<>("root");
		tree.setRoot(newRoot);
		assertEquals("Root should now hold 'root'", "root", tree.getRoot().data);
	}

	@Test
	public void testAddNode() {
		
		TreeNode<String> testRoot = new TreeNode<>("");
		tree.addNode(testRoot, "..--", "@");
		assertEquals("Node with code '..--' should return '@'", "@", tree.fetchNode(testRoot, "..--"));
	}

	@Test
	public void testUpdate() {
		try {
			tree.update();
			fail("Expected UnsupportedOperationException");
		} catch (UnsupportedOperationException e) {
			assertTrue(true); // pass
		}
	}

	@Test
	public void testInsertAndFetch() {
		
		tree.insert("..--", "#");
		assertEquals("Custom insert should return '#'", "#", tree.fetch("..--"));
	}

	@Test
	public void testFetchNode() {
		
		assertEquals("Fetching '...' should return 's'", "s", tree.fetch("..."));
		assertEquals("Fetching '-' should return 't'", "t", tree.fetch("-"));
	}

	@Test
	public void testToArrayList() {
		
		ArrayList<String> list = tree.toArrayList();
		
		// check a few expected elements in order
		assertEquals("First letter should be 'h'", "h", list.get(0));
		assertTrue("List should contain 'e'", list.contains("e"));
		assertTrue("List should contain 'g'", list.contains("g"));
	}

	@Test
	public void testLNRoutputTraversal() {
		
		ArrayList<String> list = new ArrayList<>();
		tree.LNRoutputTraversal(tree.getRoot(), list);
		assertEquals("First letter in LNR should be 'h'", "h", list.get(0));
		assertEquals("Last letter in LNR should be 'o'", "o", list.get(list.size() - 1));
	}
}
