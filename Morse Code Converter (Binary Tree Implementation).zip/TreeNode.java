

public class TreeNode<T> {
	
    public T data;
    public TreeNode<T> left;
    public TreeNode<T> right;

   
    // this constructor sets the data and intializes children to null
    public TreeNode(T data) {
    	
        this.data = data;
        this.left = null;
        this.right = null;
    }

    // this is a copy constructor to create a new node
    public TreeNode(TreeNode<T> node) {
    	
        this.data = node.data;
        this.left = node.left;
        this.right = node.right;
    }
}

