import java.util.ArrayList;


public class MorseCodeTree implements LinkedConverterTreeInterface<String> {

    private TreeNode<String> root;

    // this constructor builds the morsecode tree when an object is created
    public MorseCodeTree() {
    	
        buildTree();
    }

   
    //builds tree by inserting all the letters into the right place
    @Override
    public void buildTree() {
    	
    	// root has an empty string
        root = new TreeNode<>(""); 

        //level 1
        insert(".", "e");
        insert("-", "t");

        // 2nd level
        insert("..", "i");
        insert(".-", "a");
        insert("-.", "n");
        insert("--", "m");

        // 3rd level
        insert("...", "s");
        insert("..-", "u");
        insert(".-.", "r");
        insert(".--", "w");
        insert("-..", "d");
        insert("-.-", "k");
        insert("--.", "g");
        insert("---", "o");

        // 4th level
        insert("....", "h");
        insert("...-", "v");
        insert("..-.", "f");
        insert(".-..", "l");
        insert(".--.", "p");
        insert(".---", "j");
        insert("-...", "b");
        insert("-..-", "x");
        insert("-.-.", "c");
        insert("-.--", "y");
        insert("--..", "z");
        insert("--.-", "q");
    }

    // returns the root node of the tree
    @Override
    public TreeNode<String> getRoot() {
    	
        return root;
    }

    // this method sets the new root for the tree
    @Override
    public void setRoot(TreeNode<String> newNode) {
    	
        this.root = newNode;
    }

    
    // inserts letters into the tree based on the morse code
    @Override
    public void insert(String code, String letter) {
    	
        addNode(root, code, letter);
    }

    @Override
    public void addNode(TreeNode<String> current, String code, String letter) {
    	
        if (code.length() == 1) {
        	
            if (code.equals(".")) {
            	
                current.left = new TreeNode<>(letter);
            } 
            else if (code.equals("-")) {
            	
                current.right = new TreeNode<>(letter);
            }
        } 
        else {
            char direction = code.charAt(0);
            String rest = code.substring(1);

            if (direction == '.') {
            	
                if (current.left == null) {
                    current.left = new TreeNode<>("");
                }
                
                addNode(current.left, rest, letter);
            }
            else {
            	
                if (current.right == null) {
                    current.right = new TreeNode<>("");
                }
                
                addNode(current.right, rest, letter);
            }
        }
    }

    
    //fetches the letter corresponding to the morsecode string
    @Override
    public String fetch(String code) {
    	
        return fetchNode(root, code);
    }

    // this helps find a letter from the tree
    @Override
    public String fetchNode(TreeNode<String> current, String code) {
    	
        if (code.length() == 0) {
        	
            return current.data;
        }

        char direction = code.charAt(0);
        String rest = code.substring(1);

        if (direction == '.') {
        	
            return fetchNode(current.left, rest);
        } 
        else {
            return fetchNode(current.right, rest);
        }
    }

    @Override
    public LinkedConverterTreeInterface<String> delete(String data) throws UnsupportedOperationException {
    	
        throw new UnsupportedOperationException("Delete is not supported.");
    }

   
    @Override
    public LinkedConverterTreeInterface<String> update() throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Update is not supported.");
    }

    // returns the elements of the tree in the inorder traversal
    @Override
    public ArrayList<String> toArrayList() {
    	
        ArrayList<String> list = new ArrayList<>();
        LNRoutputTraversal(root, list);
        return list;
    }

    // this adds items to the list
    @Override
    public void LNRoutputTraversal(TreeNode<String> node, ArrayList<String> list) {
    	
        if (node != null) {
        	
            LNRoutputTraversal(node.left, list);
            list.add(node.data);
            LNRoutputTraversal(node.right, list);
        }
    }
}


