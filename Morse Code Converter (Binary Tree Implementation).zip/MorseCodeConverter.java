
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class MorseCodeConverter {

    private static MorseCodeTree tree = new MorseCodeTree();

    // converts a Morse code string into English,morse code words are separated by " / ", and letters by spaces
    public static String convertToEnglish(String code) {
    	
        StringBuilder result = new StringBuilder();

        String[] words = code.trim().split(" / ");

        for (String word : words) {
        	
            String[] letters = word.split(" ");
            
            for (String letterCode : letters) {
            	
                if (!letterCode.equals("")) {
                    result.append(tree.fetch(letterCode));
                }
            }
            
            result.append(" "); // space between words
        }

        return result.toString().trim();
    }

    // converts Morse code stored in a file into English
    public static String convertToEnglish(File file) throws FileNotFoundException {
    	
        Scanner scanner = new Scanner(file);
        StringBuilder morseCode = new StringBuilder();

        while (scanner.hasNextLine()) {
            morseCode.append(scanner.nextLine()).append(" ");
        }

        scanner.close();
        return convertToEnglish(morseCode.toString());
    }

    
    // returns the inorder traversal
    public static String printTree() {
    	
        StringBuilder output = new StringBuilder();
        
        for (String letter : tree.toArrayList()) {
        	
            if (!letter.equals("")) {
                output.append(letter).append(" ");
            }
        }
        return output.toString().trim();
    }
}

