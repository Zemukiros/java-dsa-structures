import java.io.*;

public class SpotifyManager {
    private GenericLinkedList<User> users;
    
    
    
    SpotifyManager(){
    	
    	users = new GenericLinkedList<>();;
    	
    }
     
    
    
    // geting Users
    GenericLinkedList<User> getUsers() { 
    	return users;
    	
    
    }

    
    // this is my Finduser which will be method which will 
    // match userName and password. and if match it return's user
    
    User findUser(String userN, String pass) throws UserNotFoundException, 
    InvalidPasswordException{
    	
    	if(userN == null || pass == null) throw new UserNotFoundException("user is not found!");
    	
    	// cleaing up extra spaces
    	String u = userN.trim(); 
    	String p = pass.trim();
    			
           // creating an enhanced for loop that loops 
    	// through every User stroed in my linkelist
    	// if currentuser name == the inpute, then
    	// check password
    	
    	for(User i :  users) {
    		
    		
    		if(i.getUsername().equalsIgnoreCase(u)){
    			
    			if(!i.getPassword().equals(p)) throw new InvalidPasswordException("Invalid password");
    		return i;		
    		}
    	}		
    		   throw new UserNotFoundException("User not found");	
    	
    }
    
    
    
    //here i will read user from a text file and throw exception if filenot found or 
    // text does not follow the right format
     void loadUsersFromFile(String fileN) throws IOException, InvalidUserFormatException{
    	 
    	 try(BufferedReader r=new BufferedReader(new FileReader(fileN))){
    		 // will hald each line i read
    		 String m;
    		 // keeping ttrack of my current user
    		 User u = null;
    		 // keeping track of my current playlist
    		 Playlist p= null;
    		 
    		 // reading nexline and storing in m , then when null stop
    		 while((m = r.readLine()) != null) {
    			 
    			 m=m.trim();
    			 if(m.isEmpty())
    				 continue;
    			 
    			 String lowC = m.toLowerCase();
    			 
    			 // if file read user, then u and p = null
    			 if(lowC.equals("#user")) {
    				 
    				 u=null;
    				 p=null;
    				 continue;
    			 }
    			
    			 // if line starts with username then i start after that and to give the name
    			if(lowC.startsWith("username:")) {
    				//user line
    				String un=m.substring(9).trim();
    				//pass line
    				String pLine = r.readLine();
    				
    				// checking if line starts with pass
    				//if true extracing the pass same way as userN
    				if(pLine == null || !pLine.trim().startsWith("password")){
    					throw new InvalidUserFormatException("we are excprting password");
    					}
    				String pw= pLine.trim().substring(9).trim();
				    
    				// creating a new user 
    				// adding  the user, then resting p to nul
    				u=new User(un,pw); 
				    users.addLast(u); 
				    p=null; 
				    continue;
    				
    				}
    			
    			// doing same for playlist line
    			
    			if(lowC.startsWith("playlist:")) {
    				
    				p=new Playlist(m.substring(9).trim());
    				u.addPlaylist(p);
    				continue;
    				
    			}
    			
    			// doing the same for songline
    			
    			if(lowC.startsWith("song:")) {
    				
    				String re = m.substring(5).trim();
    				int i =  re.indexOf(" - ");
    				p.addSong(new Song(re.substring(0, i).trim(), re.substring(i + 3).trim()));
    				continue;
    			}
    			
    			}
    		 }
    		 
    	 }
    	 
    	 
     } 
    
    
  

    
    	
    


