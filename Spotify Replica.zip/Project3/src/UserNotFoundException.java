
public class UserNotFoundException extends Exception{
	
	public UserNotFoundException(String mess) {
        super(mess);
    }

}
