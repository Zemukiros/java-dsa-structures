
public class InvalidPasswordException extends Exception  {
	
	public InvalidPasswordException (String mess) {
        super(mess);
    }
	
	
	

}
