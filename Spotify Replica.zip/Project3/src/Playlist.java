
import java.util.*;
import java.util.ListIterator;


public class Playlist {

	// okay so i need a filed of name where i would save
	// the name of my playlist
	// i would also need my list to store the list of songs
	// i alos need a file that will track where i am in the list
	private String Pname;
	private GenericLinkedList<Song> songs;
	private ListIterator<Song> iter;
	private Song currSong;
	
	
	
	public Playlist(String Pname) {
		
		
		this.Pname=Pname;
		this.songs= new GenericLinkedList<>();
		this.iter = songs.iterator();
		this.currSong=null;
			
	}
	
	 
	
	String getName() {
		
		return Pname;
	}
	
	// return current selected song 
	Song  getCurrentSong() {
		return currSong;
	}
	
	
	// return the size of my playlist, how many song there are
	
	int getSize() {
		
		return songs.size();
	}
	
	
	//this  will add song to the end of my playlist
	boolean addSong(Song s) {
		
		if(s == null) return false;
		songs.addLast(s);
		
		return true;
	}
	
	//here i will remove a song specified from my playlist
	// and returns true if rmoved or false otherwise
	boolean removeSong(Song s) {
		
		// if s null noting to remove exist
		if(s == null) return false;
		
		
		// here i am checking if a song
		boolean remov = songs.remove(s);
		
		// if remov and currSong != null and equal s 
		// then currSong  is null
		
		if (remov && currSong !=null && currSong.equals(s)) {
			
			
			currSong = null;
			
			iter =  songs.iterator();
			
		}
		
		return remov;
	}
	
	
	
	
 // cheking is there 0 songs
	Boolean isEmpty() {
	
	return songs.isEmpty();
	}

	//  this return a linked list of my songs 
	public GenericLinkedList<Song> getSongs() {
	    return songs;
	}
	
	///////////////////////////////////////////
	

	// here i am moving to next song and return it
	Song nextSong() {
		
		 if (songs.isEmpty() ){
		        return null;
		    }
		
		// true moveing forward and updating currSong  
		 if (iter.hasNext()) {
		        currSong = iter.next();
		       
		        }
		 else {
			 // i am at the tail so rest to first
			 iter= songs.iterator();
			 
			 // move step
			 currSong=iter.next();
			 
		 }
		 
		 return currSong;
	
	}
	
	public Song previousSong() {
	    if (songs.isEmpty() || currSong==null) {
	        return null;
	    }
	    
	    if(iter.hasPrevious()) {
	    	
	    	currSong = iter.previous();
	    }
	  else {
		
		
		  iter=songs.iterator();
		  
		  while(iter.hasNext()) {
			  iter.next();
		  }
		
		  currSong = iter.previous();
	}
	    
	    return currSong;
		
}
	

}