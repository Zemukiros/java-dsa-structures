
public class User {

	
    private String userN;
    private String pass;
	private GenericLinkedList<Playlist> playl;
    
	
	public User(String userN, String pass) {
	this.userN = userN;
    this.pass = pass;
    this.playl = new GenericLinkedList<>();
	}
	
	
	  String getUsername() {
	        return userN;
	    }
	  
	   String getPassword() {
	        return pass;
	    }
	  
	   int getPlaylistCount() {
	        return playl.size();
	    }
	
	 void addPlaylist(Playlist p) {
	        if (p != null) {
	         playl.addLast(p);
	        }
	  
	    }
	  GenericLinkedList<Playlist> getPlaylists() {
	        return playl;
	    }
	  
}
