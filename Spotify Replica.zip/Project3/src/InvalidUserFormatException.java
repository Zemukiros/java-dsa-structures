
public class InvalidUserFormatException extends Exception {
	public InvalidUserFormatException(String mess) {
        super(mess);
    }

}
