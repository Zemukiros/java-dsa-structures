import javax.print.attribute.standard.MediaSize.Other;

public class Song {
	
	private String songTitle;
	
	private String songArtist;
	
	
	 public Song(String songTitle, String songArtist) {
		 
		 
		 this.songTitle= songTitle;
		 this.songArtist = songArtist;
	 }
	 
	 
	 
	 
	 
	 //my setters
	 
	 public void setTitle(String songTitle) {
		 this.songTitle = songTitle;
	    
	 }
	 
	 
	 public void setArtist(String songArtist) {
		 
		 
		 this.songArtist=songArtist;
	 }
	 
	 
	 // my getters
	 
	 public String getTitle() {
	        return songTitle;
	    }
	 
	 public String getArtist() {
	        return songArtist;
	    }
	 
	 //  creating an equals method to check if two song are the same
	 // have the same songTitle and songArtist
	 //while ignoring case senstive
	 
	  @Override
	   public boolean equals(Object a) {
		  
		  // checking if a not null 
		  if(a == null) return false;
		  
		  // here casting to song object
		  Song other = (Song) a;
		  
		  boolean check = this.songTitle.equalsIgnoreCase(other.songTitle) && 
				  
				          this.songArtist.equalsIgnoreCase(other.songArtist);
		  
		  return check;
		  
	  }
	 
	 
	
	 @Override
	 public String toString() {
		 
	        return songTitle + " " + songArtist;
	        
	    }
	
	

}
