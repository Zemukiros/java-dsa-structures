import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.ListIterator;


public class GenericLinkedListStudentTest {
	
	
	
	private GenericLinkedList<String> list;
	
	@Before
    public void setUp() {
        list = new GenericLinkedList<>();
    }
	
	 @Test
	    public void testAddLast() {
	    	list.addLast("pizza");
	        list.addLast("burger"); // should now be at the end (index 1)
	        assertEquals("burger", list.get(1)); // confirms position at end
	    }
	 
	 @Test
	    public void testClear() {
	        list.addFirst("nubr");
	        list.clear();
	        assertFalse(list.contains("nubr"));
	    }
	 
	 @Test
	    public void iteratorForwardCheck() {
	        list.addLast("Watermelon");
	        ListIterator<String> it = list.iterator();
	        assertTrue(it.hasNext());
	        assertEquals("Watermelon", it.next());
	    }
}
