
public class Node<T> {

	// we need twp pointers, one that points to the next node and another that points to the previous one
	T data;       
    Node<T> next;  
    Node<T> prev;  

    // constructor to initialize the node with data
    public Node(T data) {
    	
        this.data = data;
        this.next = null;
        this.prev = null;
    }
    
}
