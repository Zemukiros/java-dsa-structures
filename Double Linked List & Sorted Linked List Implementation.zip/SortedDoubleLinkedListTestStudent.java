import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Comparator;
import java.util.ArrayList;

public class SortedDoubleLinkedListTestStudent {

	
	private SortedDoubleLinkedList<Integer> sortedList;
    private Comparator<Integer> comparator;

    @Before
    public void setUp() {
    	
        comparator = Integer ::compareTo;
        sortedList = new SortedDoubleLinkedList<>(comparator);
    }

    @Test
    public void testAddSorted() {
    	
        sortedList.add(50);
        sortedList.add(30);
        sortedList.add(40);
        
        
        ArrayList<Integer> elements = sortedList.toArrayList();
        assertEquals(Integer.valueOf(30), elements.get(0));
        assertEquals(Integer.valueOf(40), elements.get(1));
        assertEquals(Integer.valueOf(50), elements.get(2));
    }


    @Test
    public void testRemove() {
    	
        sortedList.add(100);
        sortedList.add(120);
        sortedList.add(110);
        
        assertEquals(Integer.valueOf(110), sortedList.remove(110, comparator));
        assertEquals(2, sortedList.getSize());
    }
}