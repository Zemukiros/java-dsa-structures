
import java.util.Comparator;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> {
	
    private Comparator<T> comparator;

    // this constructor initializes the list with a comparator
    public SortedDoubleLinkedList(Comparator<T> comparator) {
    	
        super();
        this.comparator = comparator;
    }

    // this method adds an element to the list while maintaining sorted order
    public void add(T data) {
    	
        Node<T> newNode = new Node<>(data);
        
        if (isEmpty()) {
            head = tail = newNode;
        } 
        else {
            
        	Node<T> current = head;
            while (current != null && comparator.compare(current.data, data) < 0) {
            	
                current = current.next;
            }
            
            // inserting at the front
            if (current == head) { 
                newNode.next = head;
                head.prev = newNode;
                head = newNode;
            } 
            
            // insert at the end
            else if (current == null) { 
                tail.next = newNode;
                newNode.prev = tail;
                tail = newNode;
            } 
            
            else { 
                newNode.prev = current.prev;
                newNode.next = current;
                current.prev.next = newNode;
                current.prev = newNode;
            }
        }
        size++;
    }
    
    @Override
    public void addToFront(T data) {
    	
        throw new UnsupportedOperationException("Cannot add to front in a sorted list");
    }

    @Override
    public void addToEnd(T data) {
    	
        throw new UnsupportedOperationException("Cannot add to end in a sorted list");
    }
    
}
