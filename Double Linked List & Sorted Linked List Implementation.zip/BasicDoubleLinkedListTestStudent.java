import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.Comparator;
import java.util.NoSuchElementException;
import java.util.ArrayList;

public class BasicDoubleLinkedListTestStudent {
	
	private BasicDoubleLinkedList<Integer> list;

    @Before
    public void setUp() {
        list = new BasicDoubleLinkedList<>();
    }

    @Test
    public void testAddToFront() {
        list.addToFront(10);
        list.addToFront(20);
        assertEquals(2, list.getSize());
        assertEquals(Integer.valueOf(20), list.toArrayList().get(0));
    }

    @Test
    public void testAddToEnd() {
        list.addToEnd(30);
        list.addToEnd(40);
        assertEquals(2, list.getSize());
        assertEquals(Integer.valueOf(40), list.toArrayList().get(1));
    }

    @Test
    public void testRemove() {
        list.addToEnd(50);
        list.addToEnd(60);
        list.addToEnd(70);
        Comparator<Integer> comparator = Integer::compareTo;
        assertEquals(Integer.valueOf(60), list.remove(60, comparator));
        assertEquals(2, list.getSize());
    }

   
    @Test
    public void testIteratorTraversal() {
        list.addToEnd(80);
        list.addToEnd(90);
        list.addToEnd(100);
        ArrayList<Integer> elements = list.toArrayList();
        assertEquals(Integer.valueOf(80), elements.get(0));
        assertEquals(Integer.valueOf(90), elements.get(1));
        assertEquals(Integer.valueOf(100), elements.get(2));
    }
}