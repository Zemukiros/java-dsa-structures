
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class BasicDoubleLinkedList<T> implements Iterable<T> {
	
	// declaring variables for the size and for the pointers to the first and last node of the list
    protected Node<T> head, tail;
    protected int size;
    
    public BasicDoubleLinkedList() {
    	
        head = tail = null;
        size = 0;
    }

    // adds a new node with the given data to the front of the list
    public void addToFront(T data) {
    	
        Node<T> newNode = new Node<>(data);
        
        if (isEmpty()) {
            head = tail = newNode;
        } 
        else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
        
        size++;
    }

    // adds a new node to the end of the list
    public void addToEnd(T data) {
    	
        Node<T> newNode = new Node<>(data);
        
        if (isEmpty()) {
            head = tail = newNode;
        } 
        else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        
        size++;
    }
    
    //returns the first element in the list
    public T getFirst() {
    	
    	if(head != null)
    		return head.data;
    	else
    		return null;
    }

    // returns the last element in the list
    public T getLast() {
    	
    	if(tail != null)
    		return tail.data;
    	else
    		return null;
      
    }

    // Removes and returns the first element
    public T retrieveFirstElement() {
    	
        if (head == null) 
        	return null;
        T data = head.data;
        
        head = head.next;
        if (head != null) 
        	head.prev = null;
        else 
        	tail = null;
        
        size--;
        return data;
    }

    // removes and returns the last element
    public T retrieveLastElement() {
        if (tail == null) 
        	return null;
        T data = tail.data;
        tail = tail.prev;
        
        if (tail != null) 
        	tail.next = null;
        else 
        	head = null;
        
        size--;
        return data;
    }

    // removes the first occurrence of the given chosen element 
    public T remove(T target, java.util.Comparator<T> comparator) {
    	
        Node<T> current = head;
        while (current != null) {
        	
            if (comparator.compare(current.data, target) == 0) {
                if (current == head) 
                	head = current.next;
                if (current == tail) 
                	tail = current.prev;
                if (current.next != null) 
                	current.next.prev = current.prev;
                if (current.prev != null) 
                	current.prev.next = current.next;
                
                size--;
                return current.data;
            }
            
            current = current.next;
        }
        
        return null;
    }

    // converts the linked list into an array List
    public ArrayList<T> toArrayList() {
    	
        ArrayList<T> list = new ArrayList<>();
        
        Node<T> current = head;
        while (current != null) {
        	
            list.add(current.data);
            current = current.next;
        }
        
        return list;
    }

    // returns the number of elements in the list
    public int getSize() {
        return size;
    }

    // checks if the list is empty
    public boolean isEmpty() {
        return size == 0;
    }

    
    // returns an iterator for traversing the linked list
    @Override
    public ListIterator<T> iterator() {
        return new DoubleLinkedListIterator();
    }

    private class DoubleLinkedListIterator implements ListIterator<T> {
        private Node<T> current = head;

        
        public boolean hasNext() {
            return current != null;
        }

       
        public T next() {
            if (!hasNext()) 
            	throw new NoSuchElementException();
       
            T data = current.data;
            current = current.next;
            return data;
        }

        // correctly checks if a previous element exists
        public boolean hasPrevious() {
        	
            return current != null && current.prev != null;
        }

        //moves backward through the list
        public T previous() {
            if (!hasPrevious()) 
            	throw new NoSuchElementException();
            
            current = current.prev;
            return current.data;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public void set(T e) {
            throw new UnsupportedOperationException();
        }
        @Override
        public void add(T e) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int nextIndex() {
            throw new UnsupportedOperationException();
        }
        @Override
        public int previousIndex() {
            throw new UnsupportedOperationException();
        }
    }
}
