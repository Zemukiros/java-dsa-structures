import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CourseDBManagerTestStudent {
	
	private CourseDBManagerInterface dataMgr;

	@Before
	public void setUp() throws Exception {
		
		dataMgr = new CourseDBManager();
	}

	@After
	public void tearDown() throws Exception {
		
		 dataMgr = null;
	}

	@Test
	public void testAdd() {
		
		 try {
			 
	            dataMgr.add("BIOLOGY101", 12345, 3, "RoomA1", "Hayelom T.");
	            dataMgr.add("MATH202", 54321, 4, "RoomB2", "Dr. Lemlem");
	        } 
		 catch (Exception e) {
	            fail("Adding courses should not have thrown an exception.");
	        }
		
	}


	@Test
	public void testReadFile() {
		
		 try {
	            File inputFile = new File("TestStudent.txt");
	            PrintWriter writer = new PrintWriter(inputFile);
	            writer.println("ENGL110 11111 3 RoomX Dr. Sky");
	            writer.println("CHEM220 22222 4 RoomY Dr. Earth");
	            writer.close();

	            dataMgr.readFile(inputFile);

	            assertEquals("ENGL110", dataMgr.get(11111).getID());
	            assertEquals("CHEM220", dataMgr.get(22222).getID());
	            assertEquals("RoomY", dataMgr.get(22222).getRoomNum());

	        } catch (FileNotFoundException e) {
	            fail("File should exist and be readable.");
	        } catch (Exception e) {
	            fail("Unexpected exception occurred: " + e.getMessage());
	        }
	    
		
}

	@Test
	public void testShowAll() {
		
		 dataMgr.add("HISTORY301", 33333, 3, "RoomC3", "Professor Z");
	     dataMgr.add("PHYSICS401", 44444, 4, "RoomD4", "Dr. Alpha");
	     dataMgr.add("CS101", 55555, 3, "RoomE5", "Hayelom T.");

	     ArrayList<String> course_list = dataMgr.showAll();

	        assertTrue(course_list.contains("\nCourse:HISTORY301 CRN:33333 Credits:3 Instructor:Professor Z Room:RoomC3"));
	        assertTrue(course_list.contains("\nCourse:PHYSICS401 CRN:44444 Credits:4 Instructor:Dr. Alpha Room:RoomD4"));
	        assertTrue(course_list.contains("\nCourse:CS101 CRN:55555 Credits:3 Instructor:Hayelom T. Room:RoomE5"));
		
	}

}
