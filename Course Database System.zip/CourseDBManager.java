
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {

	// a hash table  where all course data is stored
    private CourseDBStructure structure;

    // constructor initializes the CourseDBStructure with a fixed size which can be changed
    // use a small size for testing
    public CourseDBManager() {
    	
        structure = new CourseDBStructure(20); 
    }

    @Override
    // creates a CourseDBElement with the given data and adds it to the structure
    public void add(String id, int crn, int credits, String roomNum, String instructor) {
    	
        CourseDBElement element = new CourseDBElement(id, crn, credits, roomNum, instructor);
        
        // add the elements to the hash
        structure.add(element);
    }

    @Override
    // retrieves a course from the database using its ccrn
    public CourseDBElement get(int crn) {
    	
        try {
        	
            return structure.get(crn);
        } 
        catch (Exception e) {
        	
            return null;
        }
    }

    @Override
    //  reads course data from a file and adds each course to the database
    public void readFile(File input) throws FileNotFoundException {
    	
        Scanner scan = new Scanner(input);
        
        // read each line of the file and parse course data
        while (scan.hasNextLine()) {
        	
            String line = scan.nextLine();
            String[] parts = line.split(" ", 5);
            
            if (parts.length == 5) {
            	
                String id = parts[0];
                int crn = Integer.parseInt(parts[1]);
                int credits = Integer.parseInt(parts[2]);
                String room = parts[3];
                String instructor = parts[4];
                add(id, crn, credits, room, instructor);
            }
        }
        
        scan.close();
    }

    @Override
    // Returns a list of all courses in the database in formatted strings
    public ArrayList<String> showAll() {
    	
        return structure.showAll();
    }
}
