
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

//this class represents the hash table structure for storing CourseDBElement objects
public class CourseDBStructure implements CourseDBStructureInterface {
	
	// array used to handle collisions
    private LinkedList<CourseDBElement>[] hashTable;
    private int tableSize;

    
    // constructor that initializes the hash table with a given size
    public CourseDBStructure(int size) {
    	
    	 this.tableSize = size;
    	 hashTable = new LinkedList[size];
        
    }
    
    public CourseDBStructure(String name, int size) {
    	
        this(size);  
    }

    @Override
    // adds a CourseDBElement to the hash table based on its hash code
    public void add(CourseDBElement element) {
    	
    	// compute the index using hashCode and make sure it's within bounds
        int index = element.hashCode() % tableSize;
        
        if (index < 0) 
        	index += tableSize;

        if (hashTable[index] == null) {
        	
            hashTable[index] = new LinkedList<>();
        }

        // avoid duplicates if the element already exists,do nothing
        for (CourseDBElement existing_index : hashTable[index]) {
        	
            if (existing_index.equals(element)) {
                return; 
            }
        }

        hashTable[index].add(element);
       
    }

    @Override
    // retrieves a CourseDBElement from the hash table by Crn
    public CourseDBElement get(int crn) throws IOException {
    	
        int index = Integer.toString(crn).hashCode() % tableSize;
        
        if (index < 0) 
        	index += tableSize;

        // search through the bucket for a matching Crn
        if (hashTable[index] != null) {
        	
            for (CourseDBElement element : hashTable[index]) {
            	
                if (element.getCRN() == crn) {
                    return element;
                }
            }
        }

        // if no match is found, throw an exception
        throw new IOException("Course not found.");
    }

    @Override
    // returns a list of string representations of all courses in the hash table
    public ArrayList<String> showAll() {
    	
        ArrayList<String> result = new ArrayList<>();
        
        for (LinkedList<CourseDBElement> list : hashTable) {
        	
            if (list != null) {
                for (CourseDBElement element : list) {
                    result.add(element.toString()); 
                }
            }
        }

        return result;
    }

    @Override
    public int getTableSize() {
        return tableSize;
    }
    
   
}
