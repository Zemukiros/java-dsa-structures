
public class CourseDBElement {
	
    String id;
    int crn;
    int credits;
    String roomNum;
    String instructor;
    
    public CourseDBElement() {
    }

    public CourseDBElement(String id, int crn, int credits, String roomNum, String instructor) {
    	
        this.id = id;
        this.crn = crn;
        this.credits = credits;
        this.roomNum = roomNum;
        this.instructor = instructor;
    }

    // getters
    public String getID() {
    	
        return id;
    }

    public int getCRN() {
    	
        return crn;
    }

    public int getCredits() {
    	
        return credits;
    }

    public String getRoomNum() {
        return roomNum;
    }

    public String getInstructor() {
    	
        return instructor;
    }

    // setters
    public void setCRN(int crn) {
    	
        this.crn = crn;
    }
    
    public void setID(String id) {
    	this.id = id;
    }

    // this helps us find if two courses are the same based on crn
    @Override
    public boolean equals(Object obj) {
    	
        if (obj instanceof CourseDBElement) {
        	
            CourseDBElement other = (CourseDBElement) obj;
            return this.crn == other.crn;
        }
        
        return false;
    }

    // needed for placing in the table (hashing)
    @Override
    public int hashCode() {
    	
        return Integer.toString(crn).hashCode();
    }

    @Override
    public String toString() {
    	
        return "\nCourse:" + id + " CRN:" + crn + " Credits:" + credits +
               " Instructor:" + instructor + " Room:" + roomNum;
    }
}
